@echo off
chcp 65001 >nul
cd /d "%~dp0"
where pythonw >nul 2>nul
if %errorlevel%==0 (
  start "" pythonw mizan_launcher.py
) else (
  start "" /min python mizan_launcher.py
)

# -*- coding: utf-8 -*-
"""
تجهيز إصدار جديد  |  Build a release
يجمع ملفات برنامج (أو اللانشر نفسه) في حزمة zip، ويحسب بصمتها، ويكتب manifest.json الذي يقرأه اللانشر.

أمثلة:
    python make_release.py launcher 2.0.1 --note "تحسينات في الواجهة"
    python make_release.py mizan 1.1.0 --note "تحسين رسم المناطق" --note-en "Better zones"

- "launcher" يحزم ملفات اللانشر فقط (بدون apps وبدون إعداداتك).
- أي اسم آخر يحزم مجلد apps/<الاسم>، ويضيف بيانات البرنامج من apps.json داخل manifest
  حتى يقدر أي لانشر آخر يثبّته من الرابط مباشرة ("إضافة برنامج ← من رابط تحديث").
النتيجة في dist/<الاسم>/ : ارفع الملفين (zip و manifest.json) كإصدار جديد في GitHub Releases.
"""
import argparse
import hashlib
import json
import os
import zipfile
from datetime import date

ROOT = os.path.dirname(os.path.abspath(__file__))
LAUNCHER_FILES = ["mizan_launcher.py", "launcher.html", "make_release.py", "icon.ico", "icon.png",
                  "تشغيل ميزان.bat", "اقرأني - اللانشر.md"]
SKIP_DIRS = {"backups", ".updates", "__pycache__", "dist", ".git"}
SKIP_FILES = {"version.json", "launcher_config.json", "apps.json", "launcher.log"}
APP_META = {"id", "name", "desc", "type", "entry", "args", "url", "port", "requires", "needs_process",
            "keep_alive", "icon", "color"}

ap = argparse.ArgumentParser()
ap.add_argument("target", help="launcher أو معرّف البرنامج مثل mizan")
ap.add_argument("version")
ap.add_argument("--note", action="append", default=[], help="سطر من ملاحظات الإصدار بالعربية (يتكرر)")
ap.add_argument("--note-en", action="append", default=[], help="English release note line (repeatable)")
ap.add_argument("--out", default=os.path.join(ROOT, "dist"))
a = ap.parse_args()

files = []
meta = None
if a.target == "launcher":
    files = [(os.path.join(ROOT, f), f) for f in LAUNCHER_FILES if os.path.exists(os.path.join(ROOT, f))]
else:
    base = os.path.join(ROOT, "apps", a.target)
    if not os.path.isdir(base):
        raise SystemExit(f"المجلد غير موجود: {base}")
    for d, dirs, fs in os.walk(base):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
        for f in fs:
            if f not in SKIP_FILES and not f.startswith(".mz_"):
                p = os.path.join(d, f)
                files.append((p, os.path.relpath(p, base).replace(os.sep, "/")))
    try:
        with open(os.path.join(ROOT, "apps.json"), encoding="utf-8") as fh:
            app = next((x for x in json.load(fh) if x["id"] == a.target), None)
        meta = {k: v for k, v in (app or {}).items() if k in APP_META} or None
    except (OSError, ValueError):
        meta = None

out = os.path.join(a.out, a.target)
os.makedirs(out, exist_ok=True)
pkg = f"{a.target}-{a.version}.zip"
path = os.path.join(out, pkg)
with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
    for src, arc in sorted(files, key=lambda x: x[1]):
        z.write(src, arc)
        print("  +", arc)
data = open(path, "rb").read()
manifest = {
    "version": a.version,
    "date": date.today().isoformat(),
    "notes": {"ar": a.note, "en": a.note_en or a.note},
    "package": {"url": pkg, "sha256": hashlib.sha256(data).hexdigest(), "size": len(data)},
}
if meta:
    manifest["app"] = meta
with open(os.path.join(out, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
print(f"\nتم: {path}\n     {os.path.join(out, 'manifest.json')}")

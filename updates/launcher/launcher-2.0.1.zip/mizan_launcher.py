# -*- coding: utf-8 -*-
"""
لانشر ميزان  |  Mizan Launcher (مركز البرامج)
- البرنامج الرئيسي في النظام: يشغّل كل برامجك من مكان واحد (ميزان التداول وغيره).
- تضيف أي برنامج: سكربت بايثون، ملف exe أو bat، أو صفحة ويب، أو تثبّته من رابط تحديث.
- تحديث مباشر لكل برنامج وللانشر نفسه: تنزيل ← تحقق SHA-256 ← نسخة احتياطية ← تطبيق ← إعادة تشغيل.
- الواجهة عربية (مع الإنجليزية) على http://127.0.0.1:8764 فقط.

التشغيل:  اضغط مرتين على "تشغيل ميزان.bat"   أو   pythonw mizan_launcher.py
"""
import glob
import hashlib
import importlib.util
import json
import os
import re
import secrets
import shlex
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import webbrowser
import zipfile
from collections import deque
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urljoin, urlparse

LAUNCHER_VERSION = "2.0.1"
HOST, PORT = "127.0.0.1", 8764
ROOT = os.path.dirname(os.path.abspath(__file__))
UI_FILE = os.path.join(ROOT, "launcher.html")
ICON_PNG = os.path.join(ROOT, "icon.png")
ICON_ICO = os.path.join(ROOT, "icon.ico")
CONFIG_FILE = os.path.join(ROOT, "launcher_config.json")
APPS_FILE = os.path.join(ROOT, "apps.json")
APPS_DIR = os.path.join(ROOT, "apps")
HISTORY_FILE = os.path.join(ROOT, "history.json")
BACKUP_DIR = os.path.join(ROOT, "backups")
DL_DIR = os.path.join(ROOT, ".updates")
IS_WIN = os.name == "nt"
NO_WINDOW = 0x08000000 if IS_WIN else 0
LAUNCHER = "launcher"   # معرّف اللانشر نفسه في نظام التحديث

# ما لا يلمسه تحديث اللانشر أبداً
LAUNCHER_PROTECTED = {"apps", "apps.json", "launcher_config.json", "backups", ".updates", "launcher.log", "dist",
                      "history.json"}
APP_PROTECTED = {".updates", "backups", "version.json"}

# مستودع التحديثات في GitHub (عام): كل برنامج له مجلد updates/<id>/ فيه manifest.json والحزم
UPDATE_BASE = "https://raw.githubusercontent.com/kkmg80/kkmg/main/updates/"

DEFAULT_CONFIG = {
    "update_url": UPDATE_BASE + "launcher/manifest.json",   # تحديثات اللانشر نفسه
    "auto_check": True,
    "check_minutes": 30,
    "auto_apply": True,      # التحديث المباشر (بدون سؤال)
    "open_app": True,        # فتح واجهة البرنامج بعد تشغيله
}

# ميزان التداول: البرنامج الأول في المركز
MIZAN_APP = {
    "id": "mizan",
    "name": {"ar": "ميزان التداول", "en": "Mizan Trading"},
    "desc": {"ar": "مناطق العرض والطلب والتداول عبر MetaTrader 5", "en": "Supply/demand zones and trading via MetaTrader 5"},
    "type": "python",
    "dir": "apps/mizan",
    "entry": "mizan_bridge.py",
    "args": ["--no-browser"],
    "url": "http://127.0.0.1:8765",
    "port": 8765,
    "requires": ["MetaTrader5"],
    "needs_process": {"image": "terminal64.exe", "label": {"ar": "منصة MetaTrader 5", "en": "MetaTrader 5 terminal"},
                      "find": "*/terminal64.exe", "prefer": "tickmill"},
    "keep_alive": True,
    "autostart": False,
    "update_url": UPDATE_BASE + "mizan/manifest.json",
    "icon": "mizan",
    "color": "#0b6e63",
    "builtin": True,
}

TOKEN = secrets.token_urlsafe(24)
LOG = deque(maxlen=800)
LOCK = threading.RLock()
UPD = {}            # حالة التحديث لكل برنامج + اللانشر
PROCS = {}          # id -> {"proc", "started", "want"}
_last_ping = [time.time()]
_check_now = threading.Event()


# ================================================================ أدوات عامة
def log(msg, src=LAUNCHER):
    line = f"{datetime.now():%H:%M:%S}  [{src}] {msg}"
    LOG.append((src, line))
    try:
        with open(os.path.join(ROOT, "launcher.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(read_json(CONFIG_FILE, {}))
    return cfg


def vtuple(v):
    out = []
    for part in str(v).split("."):
        num = "".join(ch for ch in part if ch.isdigit())
        out.append(int(num) if num else 0)
    return tuple(out + [0] * (4 - len(out)))


def port_open(port):
    if not port:
        return False
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", int(port))) == 0


def python_exe():
    exe = sys.executable
    if IS_WIN and exe.lower().endswith("pythonw.exe"):
        alt = exe[:-11] + "python.exe"
        if os.path.exists(alt):
            return alt
    return exe


def check_url(url):
    p = urlparse(url)
    local = p.hostname in ("127.0.0.1", "localhost")
    if p.scheme != "https" and not (p.scheme == "http" and local):
        raise ValueError("الرابط لازم يبدأ بـ https://")
    return url


def fetch(url, timeout=20):
    req = urllib.request.Request(check_url(url), headers={"User-Agent": f"MizanLauncher/{LAUNCHER_VERSION}",
                                                          "Cache-Control": "no-cache"})
    return urllib.request.urlopen(req, timeout=timeout)


# ================================================================ سجل البرامج
def load_apps():
    apps = read_json(APPS_FILE, None)
    if apps is None:
        apps = [dict(MIZAN_APP)] if os.path.isdir(os.path.join(ROOT, "apps", "mizan")) else []
        write_json(APPS_FILE, apps)
    return apps


def save_apps(apps):
    write_json(APPS_FILE, apps)


def get_app(app_id):
    for a in load_apps():
        if a["id"] == app_id:
            return a
    return None


def app_dir(app):
    d = app.get("dir") or ""
    return os.path.normpath(d if os.path.isabs(d) else os.path.join(ROOT, d))


def entry_path(app):
    e = app.get("entry") or ""
    return e if os.path.isabs(e) else os.path.join(app_dir(app), e)


def slug(text):
    s = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")[:30]
    return s or "app"


def unique_id(base):
    ids = {a["id"] for a in load_apps()} | {LAUNCHER}
    i, cand = 2, base
    while cand in ids:
        cand, i = f"{base}-{i}", i + 1
    return cand


def version_of(target):
    if target == LAUNCHER:
        return read_json(os.path.join(ROOT, "version.json"), {}).get("version", LAUNCHER_VERSION)
    app = get_app(target)
    if not app:
        return "0.0.0"
    if not app.get("dir"):
        return app.get("version", "—")
    return read_json(os.path.join(app_dir(app), "version.json"), {}).get("version", app.get("version", "—"))


# ================================================================ فحص البيئة
_cache = {}


def cached(key, ttl, fn):
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    val = fn()
    _cache[key] = (time.time(), val)
    return val


def has_package(name):
    return cached("pkg:" + name, 10, lambda: importlib.util.find_spec(name) is not None)


def process_running(image):
    if not IS_WIN:
        return None

    def run():
        try:
            out = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {image}", "/NH"], capture_output=True,
                                 text=True, creationflags=NO_WINDOW, timeout=5).stdout
            return image.lower() in out.lower()
        except Exception:
            return None
    return cached("proc:" + image, 8, run)


def find_program(pattern, prefer=""):
    if not IS_WIN or not pattern:
        return None

    def run():
        for r in filter(None, [os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)")]):
            hits = sorted(glob.glob(os.path.join(r, pattern)), key=lambda p: (prefer not in p.lower(), p))
            if hits:
                return hits[0]
        return None
    return cached("find:" + pattern, 60, run)


def checks_for(app):
    out = []
    t = app.get("type")
    if t != "web":
        out.append({"kind": "file", "ok": os.path.exists(entry_path(app)), "value": os.path.basename(entry_path(app))})
    if t == "python":
        out.append({"kind": "python", "ok": True, "value": sys.version.split()[0]})
        for pkg in app.get("requires", []):
            out.append({"kind": "package", "name": pkg, "ok": has_package(pkg)})
    np_ = app.get("needs_process")
    if np_:
        path = find_program(np_.get("find"), np_.get("prefer", ""))
        out.append({"kind": "process", "label": np_.get("label"), "ok": process_running(np_["image"]),
                    "can_open": bool(path)})
    return out


# ================================================================ تشغيل البرامج
def _pump(app_id, proc):
    for raw in iter(proc.stdout.readline, b""):
        log(raw.decode("utf-8", "replace").rstrip(), app_id)
    code = proc.wait()
    log(f"توقف البرنامج (رمز الخروج {code})", app_id)


def install_packages(app_id):
    app = get_app(app_id)
    if not app:
        return False
    ok = True
    for pkg in app.get("requires", []):
        if has_package(pkg):
            continue
        log(f"تثبيت حزمة {pkg} ...", app_id)
        p = subprocess.Popen([python_exe(), "-m", "pip", "install", "--upgrade", pkg], stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, creationflags=NO_WINDOW)
        for raw in iter(p.stdout.readline, b""):
            log(raw.decode("utf-8", "replace").rstrip(), app_id)
        good = p.wait() == 0
        _cache.pop("pkg:" + pkg, None)
        log(f"تم تثبيت {pkg}" if good else f"فشل تثبيت {pkg}، راجع السجل", app_id)
        ok &= good
    return ok


def is_running(app_id):
    p = PROCS.get(app_id, {}).get("proc")
    return p is not None and p.poll() is None


def build_command(app):
    entry = entry_path(app)
    args = [str(a) for a in app.get("args", [])]
    t = app.get("type")
    if t == "python":
        return [python_exe(), "-u", entry, *args], NO_WINDOW
    if entry.lower().endswith((".bat", ".cmd")):
        return ["cmd", "/c", entry, *args], NO_WINDOW
    return [entry, *args], 0


def start_app(app_id, open_ui=None):
    app = get_app(app_id)
    if not app:
        return False, "البرنامج غير موجود"
    if open_ui is None:
        open_ui = load_config()["open_app"]
    if app.get("type") == "web":
        webbrowser.open(app["url"])
        return True, ""
    with LOCK:
        if is_running(app_id):
            return True, ""
        if port_open(app.get("port")):
            return False, f"المنفذ {app['port']} مشغول. يبدو أن البرنامج شغّال من نافذة أخرى، أغلقها أولاً."
        if not os.path.exists(entry_path(app)):
            return False, f"الملف غير موجود: {entry_path(app)}"
    if app.get("type") == "python" and app.get("requires") and not install_packages(app_id):
        if IS_WIN:
            return False, "تعذّر تثبيت الحزم المطلوبة"
    cmd, flags = build_command(app)
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1")
    with LOCK:
        try:
            proc = subprocess.Popen(cmd, cwd=app_dir(app), env=env, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, creationflags=flags)
        except OSError as e:
            return False, f"تعذّر التشغيل: {e}"
        PROCS[app_id] = {"proc": proc, "started": time.time(), "want": True}
        threading.Thread(target=_pump, args=(app_id, proc), daemon=True).start()
        log("تم التشغيل", app_id)
    if open_ui and app.get("url"):
        threading.Thread(target=_open_when_ready, args=(app,), daemon=True).start()
    return True, ""


def _open_when_ready(app):
    for _ in range(60):
        if not app.get("port") or port_open(app["port"]):
            webbrowser.open(app["url"])
            return
        if not is_running(app["id"]):
            return
        time.sleep(0.5)


def stop_app(app_id, user=True):
    with LOCK:
        st = PROCS.get(app_id)
        if not st:
            return
        if user:
            st["want"] = False
        p = st["proc"]
        if p.poll() is not None:
            return
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True, creationflags=NO_WINDOW)
        else:
            p.terminate()
        try:
            p.wait(8)
        except subprocess.TimeoutExpired:
            p.kill()
        log("تم الإيقاف", app_id)


def stop_all():
    for app_id in list(PROCS):
        stop_app(app_id)


def wanted_running():
    return [i for i, s in PROCS.items() if s.get("want")]


# ================================================================ التحديثات
def upd(target):
    return UPD.setdefault(target, {"phase": "idle", "progress": 0, "message": "", "latest": None,
                                   "last_check": None, "restart_required": False})


def set_upd(target, **kw):
    with LOCK:
        upd(target).update(kw)


def update_url_of(target):
    if target == LAUNCHER:
        return load_config()["update_url"].strip()
    app = get_app(target)
    return (app or {}).get("update_url", "").strip()


def read_manifest(url):
    with fetch(url) as r:
        man = json.loads(r.read().decode("utf-8"))
    if not {"version", "package"} <= man.keys() or not {"url", "sha256"} <= man["package"].keys():
        raise ValueError("ملف التحديث غير مكتمل")
    man["package"]["url"] = urljoin(url, man["package"]["url"])
    return man


def check_updates(target, quiet=False):
    url = update_url_of(target)
    if not url:
        if not quiet:
            set_upd(target, phase="error", message="لم يُحدَّد مصدر التحديثات بعد. أضف الرابط من الإعدادات.")
        return None
    set_upd(target, phase="checking", progress=0, message="جاري البحث عن تحديثات ...")
    try:
        man = read_manifest(url)
        newer = vtuple(man["version"]) > vtuple(version_of(target))
        set_upd(target, latest=dict(man, newer=newer), last_check=time.time(), phase="idle",
                message=("يتوفر إصدار جديد " + man["version"]) if newer else "أنت على أحدث إصدار")
        log(f"فحص التحديثات: المتاح {man['version']} / الحالي {version_of(target)}", target)
        return man if newer else None
    except Exception as e:
        if quiet:   # الفحص التلقائي: لا نزعجك برسالة خطأ (مثلاً لا يوجد إصدار منشور بعد أو لا يوجد إنترنت)
            set_upd(target, phase="idle", last_check=time.time(), message="")
        else:
            set_upd(target, phase="error", last_check=time.time(), message=f"تعذّر فحص التحديثات: {e}")
        log(f"تعذّر فحص التحديثات: {e}", target)
        return None


def _safe_members(zf, protected):
    out = []
    for info in zf.infolist():
        name = info.filename.replace("\\", "/")
        if info.is_dir():
            continue
        parts = [p for p in name.split("/") if p not in ("", ".")]
        if name.startswith("/") or ".." in parts or ":" in name or not parts:
            raise ValueError(f"مسار غير آمن داخل الحزمة: {name}")
        if parts[0] in protected:
            continue
        out.append((info, "/".join(parts)))
    return out


def _download(target, man):
    pkg = man["package"]
    os.makedirs(DL_DIR, exist_ok=True)
    dest = os.path.join(DL_DIR, f"{target}-{man['version']}.zip")
    h = hashlib.sha256()
    with fetch(pkg["url"], timeout=60) as r, open(dest, "wb") as f:
        total = int(r.headers.get("Content-Length") or pkg.get("size") or 0)
        got = 0
        while True:
            chunk = r.read(64 * 1024)
            if not chunk:
                break
            f.write(chunk)
            h.update(chunk)
            got += len(chunk)
            if total:
                set_upd(target, progress=min(99, int(got * 100 / total)))
    set_upd(target, phase="verifying", progress=100, message="التحقق من سلامة الملف ...")
    if h.hexdigest().lower() != pkg["sha256"].lower():
        os.remove(dest)
        raise ValueError("بصمة الملف لا تطابق ملف التحديث. تم الإلغاء حفاظاً على سلامة البرنامج.")
    return dest


def apply_update(target, man=None):
    with LOCK:
        u = upd(target)
        if u["phase"] in ("downloading", "verifying", "applying"):
            return False
        man = man or (u["latest"] if u["latest"] and u["latest"].get("newer") else None)
        if not man:
            return False
        set_upd(target, phase="downloading", progress=0, message=f"تنزيل الإصدار {man['version']} ...")
    is_launcher = target == LAUNCHER
    base = ROOT if is_launcher else app_dir(get_app(target))
    protected = LAUNCHER_PROTECTED if is_launcher else APP_PROTECTED | set(man.get("keep", []))
    was_running = [] if is_launcher else ([target] if is_running(target) else [])
    try:
        dest = _download(target, man)
        set_upd(target, phase="applying", message="تطبيق التحديث ...")
        with zipfile.ZipFile(dest) as zf:
            members = _safe_members(zf, protected)
            old = version_of(target)
            fresh = not os.path.exists(os.path.join(base, "version.json"))
            bdir = os.path.join(BACKUP_DIR, target, f"{old}_{datetime.now():%Y%m%d-%H%M%S}")
            if fresh:
                bdir = os.path.join(DL_DIR, f"_discard_{target}")
            os.makedirs(bdir, exist_ok=True)
            added, launcher_changed = [], False
            for _, rel in members:
                tgt = os.path.join(base, *rel.split("/"))
                if os.path.exists(tgt):
                    os.makedirs(os.path.dirname(os.path.join(bdir, rel)), exist_ok=True)
                    shutil.copy2(tgt, os.path.join(bdir, rel))
                else:
                    added.append(rel)
            vf = os.path.join(base, "version.json")
            if os.path.exists(vf):
                shutil.copy2(vf, os.path.join(bdir, "version.json"))
            write_json(os.path.join(bdir, "_backup.json"),
                       {"from": old, "to": man["version"], "added": added, "time": datetime.now().isoformat()})
            for app_id in was_running:
                stop_app(app_id, user=False)
            for info, rel in members:
                tgt = os.path.join(base, *rel.split("/"))
                os.makedirs(os.path.dirname(tgt), exist_ok=True)
                fd, tmp = tempfile.mkstemp(dir=os.path.dirname(tgt), prefix=".mz_")
                with os.fdopen(fd, "wb") as out, zf.open(info) as src:
                    shutil.copyfileobj(src, out)
                if is_launcher and rel == "mizan_launcher.py":
                    try:
                        with open(tmp, "rb") as a, open(tgt, "rb") as b:
                            launcher_changed = a.read() != b.read()
                    except OSError:
                        launcher_changed = True
                os.replace(tmp, tgt)
        write_json(os.path.join(base, "version.json"), {"version": man["version"], "updated": datetime.now().isoformat()})
        if fresh:
            shutil.rmtree(bdir, ignore_errors=True)
        _prune_backups(target)
        try:
            os.remove(dest)
        except OSError:
            pass
        add_history(target, man, old)
        log(f"تم التحديث من {old} إلى {man['version']}", target)
        set_upd(target, phase="done", progress=100, latest=dict(man, newer=False),
                message=f"تم التحديث إلى الإصدار {man['version']}")
        for app_id in was_running:
            start_app(app_id, open_ui=False)
        if launcher_changed:
            set_upd(target, restart_required=True, phase="restarting", message="تم التحديث. إعادة تشغيل اللانشر ...")
            threading.Thread(target=restart_launcher, daemon=True).start()
        return True
    except Exception as e:
        log(f"فشل التحديث: {e}", target)
        set_upd(target, phase="error", message=f"فشل التحديث: {e}")
        for app_id in was_running:
            if not is_running(app_id):
                start_app(app_id, open_ui=False)
        return False


def add_history(target, man, old):
    """سجل الإصدارات: رقم كل تحديث وتاريخه وملاحظاته."""
    h = read_json(HISTORY_FILE, {})
    h.setdefault(target, []).insert(0, {"version": man["version"], "from": old,
                                        "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
                                        "released": man.get("date", ""), "notes": man.get("notes", {})})
    h[target] = h[target][:30]
    write_json(HISTORY_FILE, h)


def history_of(target):
    return read_json(HISTORY_FILE, {}).get(target, [])[:15]


def list_backups(target):
    out = []
    for d in sorted(glob.glob(os.path.join(BACKUP_DIR, target, "*")), reverse=True):
        meta = read_json(os.path.join(d, "_backup.json"), None)
        if meta:
            out.append(dict(meta, id=os.path.basename(d)))
    return out


def _prune_backups(target, keep=3):
    for b in list_backups(target)[keep:]:
        shutil.rmtree(os.path.join(BACKUP_DIR, target, b["id"]), ignore_errors=True)


def rollback(target):
    backups = list_backups(target)
    if not backups:
        return False, "لا توجد نسخة احتياطية"
    b = backups[0]
    bdir = os.path.join(BACKUP_DIR, target, b["id"])
    base = ROOT if target == LAUNCHER else app_dir(get_app(target))
    was_running = target != LAUNCHER and is_running(target)
    if was_running:
        stop_app(target, user=False)
    for root, _, files in os.walk(bdir):
        for fn in files:
            if fn == "_backup.json":
                continue
            src = os.path.join(root, fn)
            dst = os.path.join(base, os.path.relpath(src, bdir))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
    for rel in b.get("added", []):
        try:
            os.remove(os.path.join(base, *rel.split("/")))
        except OSError:
            pass
    shutil.rmtree(bdir, ignore_errors=True)
    log(f"تم الرجوع إلى الإصدار {b['from']}", target)
    set_upd(target, phase="done", message=f"تم الرجوع إلى الإصدار {b['from']}", latest=None)
    if was_running:
        start_app(target, open_ui=False)
    if target == LAUNCHER:
        threading.Thread(target=restart_launcher, daemon=True).start()
    return True, ""


def all_targets():
    return [LAUNCHER] + [a["id"] for a in load_apps() if a.get("update_url")]


def updater_loop():
    time.sleep(3)
    while True:
        cfg = load_config()
        if cfg["auto_check"]:
            for target in all_targets():
                if not update_url_of(target):
                    continue
                man = check_updates(target, quiet=True)
                if man and cfg["auto_apply"]:
                    apply_update(target, dict(man, newer=True))
                if upd(target).get("restart_required"):
                    return
        waited = 0
        while waited < max(5, cfg["check_minutes"]) * 60:
            time.sleep(5)
            waited += 5
            # البرامج المطلوب بقاؤها شغّالة: نعيد تشغيلها إذا توقفت (مرة كل دقيقة كحد أقصى)
            for app in load_apps():
                st = PROCS.get(app["id"])
                if app.get("keep_alive") and st and st["want"] and not is_running(app["id"]) \
                        and upd(app["id"])["phase"] != "applying" and time.time() - st["started"] > 60:
                    log("توقف بشكل غير متوقع، إعادة التشغيل ...", app["id"])
                    start_app(app["id"], open_ui=False)
            if _check_now.is_set():
                _check_now.clear()
                break


def restart_launcher():
    time.sleep(1.5)
    log("إعادة تشغيل اللانشر بالإصدار الجديد ...")
    running = wanted_running()
    stop_all()
    args = [sys.executable, os.path.abspath(__file__), "--relaunch"]
    if running:
        args += ["--start", ",".join(running)]
    subprocess.Popen(args, cwd=ROOT, creationflags=NO_WINDOW)
    os._exit(0)


def watchdog():
    """يغلق اللانشر إذا أُغلقت نافذته ولا يوجد برنامج شغّال."""
    while True:
        time.sleep(15)
        busy = any(u["phase"] in ("downloading", "verifying", "applying") for u in UPD.values())
        if time.time() - _last_ping[0] > 180 and not wanted_running() and not busy:
            log("تم إغلاق نافذة اللانشر")
            os._exit(0)


# ================================================================ إدارة البرامج (إضافة / تعديل / حذف)
APP_FIELDS = {"name", "desc", "type", "entry", "args", "url", "port", "update_url", "autostart", "keep_alive",
              "icon", "color", "requires"}


def clean_app_fields(body):
    out = {}
    for k in APP_FIELDS & body.keys():
        v = body[k]
        if k in ("name", "desc"):
            v = {"ar": str(v), "en": str(v)} if isinstance(v, str) else {l: str(v[l]) for l in ("ar", "en") if l in v}
        elif k == "args":
            v = shlex.split(v, posix=not IS_WIN) if isinstance(v, str) else [str(a) for a in v]
        elif k == "port":
            v = int(v) if str(v).strip().isdigit() else None
        elif k in ("autostart", "keep_alive"):
            v = bool(v)
        elif k == "requires":
            v = [s.strip() for s in (v.split(",") if isinstance(v, str) else v) if s.strip()]
        else:
            v = str(v).strip()
        out[k] = v
    if out.get("type") and out["type"] not in ("python", "exe", "web"):
        raise ValueError("نوع البرنامج غير معروف")
    if out.get("update_url"):
        check_url(out["update_url"])
    if out.get("url") and urlparse(out["url"]).scheme not in ("http", "https"):
        raise ValueError("رابط الواجهة لازم يبدأ بـ http أو https")
    if out.get("color") and not re.fullmatch(r"#[0-9a-fA-F]{6}", out["color"]):
        out.pop("color")
    return out


def add_local_app(body):
    f = clean_app_fields(body)
    if not (f.get("name") or {}).get("ar"):
        raise ValueError("اكتب اسم البرنامج")
    t = f.get("type", "exe")
    app = {"id": unique_id(slug(f["name"].get("en") or body.get("path", "") or "app")), "type": t,
           "args": [], "autostart": False, "keep_alive": False, "update_url": "", "icon": "box",
           "color": "#3a6ea5", "requires": []}
    app.update(f)
    for k in ("name", "desc"):
        d = app.get(k) or {}
        app[k] = {"ar": d.get("ar") or d.get("en", ""), "en": d.get("en") or d.get("ar", "")}
    if t == "web":
        if not app.get("url"):
            raise ValueError("اكتب رابط الصفحة")
        app["dir"] = ""
    else:
        path = os.path.abspath(str(body.get("path", "")).strip().strip('"'))
        if not os.path.isfile(path):
            raise ValueError("الملف غير موجود. اختر ملف البرنامج من جهازك")
        app["dir"], app["entry"] = os.path.dirname(path), os.path.basename(path)
        if path.lower().endswith((".py", ".pyw")):
            app["type"] = "python"
    apps = load_apps()
    apps.append(app)
    save_apps(apps)
    log(f"تمت إضافة البرنامج: {app['name']['ar']}", app["id"])
    return app


def install_from_url(url):
    """يثبّت برنامجاً من رابط manifest.json فيه قسم app."""
    man = read_manifest(check_url(url))
    meta = man.get("app") if isinstance(man.get("app"), dict) else {}
    if not meta.get("entry") and meta.get("type") != "web":
        raise ValueError("ملف التحديث لا يحتوي بيانات البرنامج (app.entry)")
    f = clean_app_fields(meta)
    app_id = unique_id(slug(meta.get("id") or (f.get("name") or {}).get("en") or "app"))
    app = {"id": app_id, "type": "python", "args": [], "autostart": False, "keep_alive": False, "icon": "box",
           "color": "#3a6ea5", "requires": [], "name": {"ar": app_id, "en": app_id}}
    app.update(f)
    app.update(dir=f"apps/{app_id}", update_url=url)
    os.makedirs(app_dir(app), exist_ok=True)
    apps = load_apps()
    apps.append(app)
    save_apps(apps)
    log(f"تثبيت البرنامج {app['name']['ar']} من الرابط ...", app_id)
    threading.Thread(target=lambda: apply_update(app_id, dict(man, newer=True)) or None, daemon=True).start()
    return app


def edit_app(app_id, body):
    f = clean_app_fields(body)
    apps = load_apps()
    for a in apps:
        if a["id"] == app_id:
            if body.get("path") and a.get("type") != "web":
                path = os.path.abspath(str(body["path"]).strip().strip('"'))
                if not os.path.isfile(path):
                    raise ValueError("الملف غير موجود")
                if not a.get("builtin"):
                    a["dir"], a["entry"] = os.path.dirname(path), os.path.basename(path)
            for k in ("name", "desc"):
                if k in f:
                    f[k] = dict(a.get(k) or {}, **f[k])
            a.update(f)
            save_apps(apps)
            return a
    raise ValueError("البرنامج غير موجود")


def remove_app(app_id):
    stop_app(app_id)
    apps = [a for a in load_apps() if a["id"] != app_id]
    save_apps(apps)
    PROCS.pop(app_id, None)
    UPD.pop(app_id, None)
    log("تمت إزالة البرنامج من اللانشر (ملفاته باقية على الجهاز)", app_id)


def move_app(app_id, delta):
    apps = load_apps()
    i = next((k for k, a in enumerate(apps) if a["id"] == app_id), None)
    if i is None:
        return
    j = max(0, min(len(apps) - 1, i + delta))
    apps.insert(j, apps.pop(i))
    save_apps(apps)


def browse_file():
    """يفتح نافذة اختيار ملف من ويندوز ويرجع المسار."""
    if IS_WIN:
        ps = ("Add-Type -AssemblyName System.Windows.Forms;"
              "$f=New-Object System.Windows.Forms.OpenFileDialog;"
              "$f.Filter='Programs (*.exe;*.py;*.pyw;*.bat;*.cmd)|*.exe;*.py;*.pyw;*.bat;*.cmd|All files (*.*)|*.*';"
              "$o=New-Object System.Windows.Forms.Form -Property @{TopMost=$true};"
              "if($f.ShowDialog($o) -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;Write-Output $f.FileName}")
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], capture_output=True,
                               creationflags=NO_WINDOW, timeout=600)
            return r.stdout.decode("utf-8", "replace").strip()
        except Exception as e:
            log(f"تعذّر فتح نافذة الاختيار: {e}")
            return ""
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        path = filedialog.askopenfilename()
        root.destroy()
        return path or ""
    except Exception:
        return ""


def make_shortcut():
    if not IS_WIN:
        return False, "متاح على ويندوز فقط"
    bat = os.path.join(ROOT, "تشغيل ميزان.bat")
    exe = os.path.join(os.path.dirname(ROOT), "Mizan Launcher.exe")   # النسخة المثبّتة بالمثبّت
    pyw = os.path.join(os.path.dirname(python_exe()), "pythonw.exe")
    if os.path.exists(exe):
        target, args = exe, ""
    elif os.path.exists(pyw):
        target, args = pyw, f'"{os.path.abspath(__file__)}"'
    else:
        target, args = bat, ""
    ps = ("$d=[Environment]::GetFolderPath('Desktop');"
          "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'لانشر ميزان.lnk'));"
          f"$s.TargetPath='{target}';$s.Arguments='{args}';$s.WorkingDirectory='{ROOT}';"
          f"$s.IconLocation='{ICON_ICO},0';$s.Description='Mizan Launcher';$s.Save()")
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                       creationflags=NO_WINDOW)
    if r.returncode != 0:
        return False, r.stderr.strip()[:200] or "تعذّر إنشاء الاختصار"
    log("تم إنشاء اختصار على سطح المكتب")
    return True, ""


# ================================================================ نافذة الواجهة
WINDOW_TITLES = ("لانشر ميزان", "Mizan Launcher")


def focus_existing_window():
    """إذا كانت نافذة اللانشر مفتوحة نرجعها للأمام بدل فتح نافذة ثانية."""
    if not IS_WIN:
        return False
    try:
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        found = []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def cb(hwnd, _):
            if not u.IsWindowVisible(hwnd):
                return True
            buf = ctypes.create_unicode_buffer(512)
            u.GetWindowTextW(hwnd, buf, 512)
            cls = ctypes.create_unicode_buffer(256)
            u.GetClassNameW(hwnd, cls, 256)
            if cls.value.startswith("Chrome_WidgetWin") and any(t in buf.value for t in WINDOW_TITLES):
                found.append(hwnd)
                return False
            return True
        u.EnumWindows(cb, 0)
        if not found:
            return False
        h = found[0]
        if u.IsIconic(h):
            u.ShowWindow(h, 9)   # SW_RESTORE
        u.SetForegroundWindow(h)
        return True
    except Exception:
        return False


def show_window(url):
    if not focus_existing_window():
        open_window(url)


def open_window(url):
    if IS_WIN:
        for k in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
            for p in (("Microsoft", "Edge", "Application", "msedge.exe"), ("Google", "Chrome", "Application", "chrome.exe")):
                exe = os.path.join(os.environ.get(k, ""), *p)
                if os.path.exists(exe):
                    subprocess.Popen([exe, f"--app={url}", "--window-size=1180,780"], creationflags=NO_WINDOW)
                    return
    webbrowser.open(url)


# ================================================================ خادم الواجهة
def app_view(a):
    st = PROCS.get(a["id"], {})
    running = is_running(a["id"])
    return dict(a, version=version_of(a["id"]), running=running, port_open=port_open(a.get("port")),
                started=st.get("started") if running else None, want=st.get("want", False),
                checks=checks_for(a), update=upd(a["id"]), backups=list_backups(a["id"])[:3],
                history=history_of(a["id"]))


def snapshot():
    with LOCK:
        return {
            "launcher": {"version": version_of(LAUNCHER), "code_version": LAUNCHER_VERSION, "update": upd(LAUNCHER),
                         "backups": list_backups(LAUNCHER)[:3], "is_windows": IS_WIN,
                         "history": history_of(LAUNCHER)},
            "apps": [app_view(a) for a in load_apps()],
            "config": load_config(),
            "log": [{"src": s, "line": l} for s, l in list(LOG)[-300:]],
        }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _guard(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        if host not in ("127.0.0.1", "localhost"):
            self._send(403, {"ok": False})
            return False
        if self.path.startswith("/api/") and self.headers.get("X-Mizan-Token") != TOKEN:
            self._send(403, {"ok": False, "error": "token"})
            return False
        return True

    def do_GET(self):
        if not self._guard():
            return
        path = urlparse(self.path).path
        if path == "/":
            with open(UI_FILE, encoding="utf-8") as f:
                html = f.read().replace("__MIZAN_TOKEN__", TOKEN)
            return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")
        if path == "/icon.png" and os.path.exists(ICON_PNG):
            with open(ICON_PNG, "rb") as f:
                return self._send(200, f.read(), "image/png")
        if path == "/api/status":
            _last_ping[0] = time.time()
            return self._send(200, snapshot())
        self._send(404, {"ok": False})

    def do_POST(self):
        if not self._guard():
            return
        path = urlparse(self.path).path
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
        except ValueError:
            body = {}
        try:
            return self._route(path, body)
        except ValueError as e:
            return self._send(400, {"ok": False, "error": str(e)})
        except Exception as e:  # pragma: no cover
            log(f"خطأ: {e}")
            return self._send(500, {"ok": False, "error": str(e)})

    def _route(self, path, body):
        bg = lambda fn, *a: threading.Thread(target=fn, args=a, daemon=True).start()  # noqa: E731
        app_id = str(body.get("id", ""))
        target = app_id or LAUNCHER
        ok = lambda **kw: self._send(200, dict(ok=True, **kw))  # noqa: E731
        if path == "/api/start":
            good, err = start_app(app_id)
            return self._send(200, {"ok": good, "error": err})
        if path == "/api/stop":
            stop_app(app_id)
            return ok()
        if path == "/api/open":
            a = get_app(app_id)
            if a and a.get("url"):
                webbrowser.open(a["url"])
            return ok()
        if path == "/api/open-process":
            a = get_app(app_id) or {}
            np_ = a.get("needs_process") or {}
            p = find_program(np_.get("find"), np_.get("prefer", ""))
            if p:
                subprocess.Popen([p])
            return self._send(200, {"ok": bool(p)})
        if path == "/api/open-folder":
            a = get_app(app_id)
            d = app_dir(a) if a else ROOT
            if IS_WIN and os.path.isdir(d):
                os.startfile(d)  # noqa
            return ok()
        if path == "/api/install-packages":
            bg(install_packages, app_id)
            return ok()
        if path == "/api/check":
            bg(check_updates, target)
            return ok()
        if path == "/api/update":
            bg(apply_update, target)
            return ok()
        if path == "/api/rollback":
            good, err = rollback(target)
            return self._send(200, {"ok": good, "error": err})
        if path == "/api/apps/add":
            if body.get("manifest_url"):
                return ok(app=install_from_url(body["manifest_url"].strip()))
            return ok(app=add_local_app(body))
        if path == "/api/apps/edit":
            a = edit_app(app_id, body)
            _check_now.set()
            return ok(app=a)
        if path == "/api/apps/remove":
            remove_app(app_id)
            return ok()
        if path == "/api/apps/move":
            move_app(app_id, int(body.get("delta", 0)))
            return ok()
        if path == "/api/browse":
            return ok(path=browse_file())
        if path == "/api/shortcut":
            good, err = make_shortcut()
            return self._send(200, {"ok": good, "error": err})
        if path == "/api/config":
            cfg = load_config()
            for k, v in body.items():
                if k in DEFAULT_CONFIG and type(v) is type(DEFAULT_CONFIG[k]):
                    cfg[k] = v
            if cfg["update_url"]:
                check_url(cfg["update_url"])
            cfg["check_minutes"] = max(5, min(1440, cfg["check_minutes"]))
            write_json(CONFIG_FILE, cfg)
            _check_now.set()
            return ok()
        if path == "/api/quit":
            stop_all()
            self._send(200, {"ok": True})
            threading.Timer(0.5, lambda: os._exit(0)).start()
            return
        self._send(404, {"ok": False})


def main():
    args = sys.argv[1:]
    url = f"http://{HOST}:{PORT}/"
    relaunch = "--relaunch" in args
    # نسخة واحدة فقط: إذا كان اللانشر شغّالاً نفتح نافذته فقط
    for _ in range(20 if relaunch else 1):
        if not port_open(PORT):
            break
        time.sleep(0.5)
    else:
        if not relaunch:
            show_window(url)
            return
    if not os.path.exists(os.path.join(ROOT, "version.json")):
        write_json(os.path.join(ROOT, "version.json"), {"version": LAUNCHER_VERSION})
    if not os.path.exists(CONFIG_FILE):
        write_json(CONFIG_FILE, DEFAULT_CONFIG)
    apps = load_apps()
    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError:   # نسخة ثانية بدأت في نفس اللحظة: نكتفي بإظهار النافذة
        time.sleep(1)
        show_window(url)
        return
    log(f"اللانشر {version_of(LAUNCHER)} يعمل، عدد البرامج {len(apps)}")
    threading.Thread(target=updater_loop, daemon=True).start()
    if "--no-watchdog" not in args:
        threading.Thread(target=watchdog, daemon=True).start()
    to_start = []
    if "--start" in args:
        to_start = [s for s in args[args.index("--start") + 1].split(",") if s]
    elif not relaunch:
        to_start = [a["id"] for a in apps if a.get("autostart")]
    for app_id in to_start:
        threading.Thread(target=start_app, args=(app_id,), kwargs={"open_ui": not relaunch}, daemon=True).start()
    if not relaunch and "--no-window" not in args:
        open_window(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        stop_all()


if __name__ == "__main__":
    main()

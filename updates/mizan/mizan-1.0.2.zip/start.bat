@echo off
chcp 65001 >nul
cd /d "%~dp0"
python -m pip install --quiet --upgrade MetaTrader5
python mizan_bridge.py %*
pause

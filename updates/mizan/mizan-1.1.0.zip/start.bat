@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PY=python
py -3.14 -c "1" >nul 2>nul && set PY=py -3.14
%PY% -m pip install --quiet --upgrade MetaTrader5
%PY% mizan_bridge.py %*
pause

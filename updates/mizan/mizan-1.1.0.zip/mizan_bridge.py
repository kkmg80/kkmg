# -*- coding: utf-8 -*-
"""
جسر ميزان التداول  |  Mizan bridge
يربط واجهة ميزان التداول العربية بمنصة MetaTrader 5 (حساب Tickmill) على نفس الجهاز.

- يعمل على ويندوز فقط (شرط حزمة MetaTrader5 الرسمية).
- يقدّم الواجهة على http://127.0.0.1:8765 فقط (لا يمكن الوصول له من خارج الجهاز).
- الحساب الحقيقي مقفل افتراضياً. للسماح به شغّل:  python mizan_bridge.py --allow-real

التشغيل:
    pip install MetaTrader5
    python mizan_bridge.py
"""
import argparse
import glob
import json
import os
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

try:
    import MetaTrader5 as mt5
except ImportError:  # pragma: no cover
    print("لم يتم العثور على حزمة MetaTrader5. ثبّتها بالأمر:  pip install MetaTrader5")
    sys.exit(1)

HOST, PORT = "127.0.0.1", 8765
MAGIC = 26111901
HERE = os.path.dirname(os.path.abspath(__file__))
WEB_FILE = os.path.join(HERE, "index.html")

# مفاتيح قائمة المتابعة في الواجهة -> أسماء محتملة للرمز عند الوسيط (أول تطابق يُستخدم)
WATCH = {
    "BTC/USDT": ["BTCUSD", "BTCUSDT", "BITCOIN"],
    "ETH/USDT": ["ETHUSD", "ETHUSDT", "ETHEREUM"],
    "SOL/USDT": ["SOLUSD", "SOLUSDT", "SOLANA"],
    "XAU/USD": ["XAUUSD", "GOLD"],
    "XAG/USD": ["XAGUSD", "SILVER"],
    "AAPL": ["AAPL"],
    "NVDA": ["NVDA"],
    "MSFT": ["MSFT"],
    "2222.SR": ["2222", "ARAMCO"],
    "SPY": ["SPY"],
    "QQQ": ["QQQ"],
    "GLD": ["GLD"],
}

TF = {
    "h1": mt5.TIMEFRAME_H1,
    "h4": mt5.TIMEFRAME_H4,
    "d1": mt5.TIMEFRAME_D1,
    "w1": mt5.TIMEFRAME_W1,
}

ALLOW_REAL = os.environ.get("MIZAN_ALLOW_REAL") == "1"
VERSION = "1.1.0"


def find_terminal():
    """يختار منصة MT5 الخاصة بالوسيط (Tickmill أولاً) إذا كان على الجهاز أكثر من نسخة."""
    env = os.environ.get("MIZAN_MT5_PATH")
    if env and os.path.isfile(env):
        return env
    roots = [os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", "")]
    hits = []
    for r in filter(None, roots):
        hits += glob.glob(os.path.join(r, "*", "terminal64.exe"))
    pref = os.environ.get("MIZAN_BROKER", "tickmill").lower()
    hits.sort(key=lambda p: (pref not in p.lower(), p))
    return hits[0] if hits else None


MT5_PATH = None


def mt5_init():
    return mt5.initialize(path=MT5_PATH) if MT5_PATH else mt5.initialize()
LOCK = threading.Lock()  # حزمة MetaTrader5 غير آمنة مع تعدد الخيوط


def mt5_ready():
    if mt5.terminal_info() is None:
        return mt5_init()
    return True


def is_demo(acc):
    return acc is not None and acc.trade_mode == mt5.ACCOUNT_TRADE_MODE_DEMO


def trading_allowed():
    acc = mt5.account_info()
    if acc is None:
        return False, "لا يوجد حساب مسجّل في MetaTrader 5"
    term = mt5.terminal_info()
    if term is not None and not term.trade_allowed:
        return False, "التداول الآلي مقفل في MetaTrader 5. فعّل زر Algo Trading"
    if not is_demo(acc) and not ALLOW_REAL:
        return False, "هذا حساب حقيقي، والجسر يعمل على الحساب التجريبي فقط ما لم تشغّله بخيار --allow-real"
    return True, ""


_symbol_cache = {}


def resolve(key):
    """يحوّل رمز الواجهة إلى اسم الرمز عند الوسيط."""
    if key in _symbol_cache:
        return _symbol_cache[key]
    names = [s.name for s in (mt5.symbols_get() or [])]
    upper = {n.upper(): n for n in names}
    found = None
    for cand in WATCH.get(key, [key]):
        c = cand.upper()
        if c in upper:
            found = upper[c]
            break
        starts = [n for n in names if n.upper().startswith(c)]
        if starts:
            found = sorted(starts, key=len)[0]
            break
    if found is None:
        for cand in WATCH.get(key, [key]):
            hits = [n for n in names if cand.upper() in n.upper()]
            if hits:
                found = sorted(hits, key=len)[0]
                break
    if found:
        mt5.symbol_select(found, True)
    _symbol_cache[key] = found
    return found


def sym_info(name):
    i = mt5.symbol_info(name)
    if i is None:
        return None
    return {
        "name": name,
        "digits": i.digits,
        "vmin": i.volume_min,
        "vmax": i.volume_max,
        "vstep": i.volume_step,
        "desc": i.description,
    }


def norm_volume(info, vol):
    step = info.volume_step or 0.01
    vol = max(info.volume_min, min(info.volume_max, round(round(vol / step) * step, 8)))
    return vol


def filling_for(info):
    fm = info.filling_mode
    if fm & 1:
        return mt5.ORDER_FILLING_FOK
    if fm & 2:
        return mt5.ORDER_FILLING_IOC
    return mt5.ORDER_FILLING_RETURN


def place_order(body):
    ok, why = trading_allowed()
    if not ok:
        return 403, {"ok": False, "error": why}

    name = body.get("symbol")
    info = mt5.symbol_info(name) if name else None
    if info is None:
        return 400, {"ok": False, "error": "رمز غير معروف"}
    if not info.visible:
        mt5.symbol_select(name, True)

    side = body.get("side")
    otype = body.get("type", "market")
    if side not in ("buy", "sell") or otype not in ("market", "limit"):
        return 400, {"ok": False, "error": "طلب غير صالح"}
    try:
        vol = norm_volume(info, float(body.get("volume", 0)))
        sl = float(body.get("sl") or 0)
        tp = float(body.get("tp") or 0)
        price = float(body.get("price") or 0)
    except (TypeError, ValueError):
        return 400, {"ok": False, "error": "أرقام غير صالحة"}
    if vol <= 0:
        return 400, {"ok": False, "error": "الحجم غير صالح"}

    tick = mt5.symbol_info_tick(name)
    if tick is None:
        return 503, {"ok": False, "error": "لا توجد أسعار لهذا الرمز الآن"}

    d = info.digits
    if otype == "market":
        req = {
            "action": mt5.TRADE_ACTION_DEAL,
            "type": mt5.ORDER_TYPE_BUY if side == "buy" else mt5.ORDER_TYPE_SELL,
            "price": tick.ask if side == "buy" else tick.bid,
            "type_filling": filling_for(info),
            "deviation": 20,
        }
    else:
        if price <= 0:
            return 400, {"ok": False, "error": "حدّد سعر الأمر المحدد"}
        if side == "buy" and price >= tick.ask:
            return 400, {"ok": False, "error": "سعر الشراء المحدد يجب أن يكون تحت السعر الحالي"}
        if side == "sell" and price <= tick.bid:
            return 400, {"ok": False, "error": "سعر البيع المحدد يجب أن يكون فوق السعر الحالي"}
        req = {
            "action": mt5.TRADE_ACTION_PENDING,
            "type": mt5.ORDER_TYPE_BUY_LIMIT if side == "buy" else mt5.ORDER_TYPE_SELL_LIMIT,
            "price": round(price, d),
            "type_filling": mt5.ORDER_FILLING_RETURN,
            "type_time": mt5.ORDER_TIME_GTC,
        }
    req.update({
        "symbol": name,
        "volume": vol,
        "sl": round(sl, d) if sl else 0.0,
        "tp": round(tp, d) if tp else 0.0,
        "magic": MAGIC,
        "comment": "Mizan",
    })
    res = mt5.order_send(req)
    if res is None:
        return 500, {"ok": False, "error": "فشل الإرسال: %s" % (mt5.last_error(),)}
    good = res.retcode in (mt5.TRADE_RETCODE_DONE, mt5.TRADE_RETCODE_PLACED, mt5.TRADE_RETCODE_DONE_PARTIAL)
    return (200 if good else 400), {
        "ok": good,
        "retcode": res.retcode,
        "order": res.order,
        "deal": res.deal,
        "volume": vol,
        "error": "" if good else (res.comment or "رفض الوسيط الأمر"),
    }


def cancel_order(body):
    ok, why = trading_allowed()
    if not ok:
        return 403, {"ok": False, "error": why}
    ticket = int(body.get("ticket", 0))
    res = mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": ticket})
    good = res is not None and res.retcode == mt5.TRADE_RETCODE_DONE
    return (200 if good else 400), {"ok": good, "error": "" if good else getattr(res, "comment", "تعذّر الإلغاء")}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, code, data):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _host_ok(self):
        # يمنع مواقع أخرى من استخدام الجسر عبر DNS rebinding
        h = (self.headers.get("Host") or "").split(":")[0]
        return h in ("127.0.0.1", "localhost")

    def do_GET(self):
        if not self._host_ok():
            return self._json(403, {"error": "forbidden"})
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path in ("/", "/index.html"):
            with open(WEB_FILE, "rb") as f:
                raw = f.read()
            if not raw.lstrip().lower().startswith(b"<!doctype"):
                raw = (b'<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">'
                       b'<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
                       b'<style>body{margin:0}img{max-width:100%}</style></head><body>' + raw + b"</body></html>")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
            return
        with LOCK:
            if not mt5_ready():
                return self._json(503, {"connected": False, "error": "تعذّر الاتصال بـ MetaTrader 5. تأكد أنه مفتوح ومسجّل الدخول"})
            if u.path == "/api/status":
                acc = mt5.account_info()
                ok, why = trading_allowed()
                return self._json(200, {
                    "connected": acc is not None,
                    "login": getattr(acc, "login", None),
                    "server": getattr(acc, "server", ""),
                    "company": getattr(acc, "company", ""),
                    "demo": is_demo(acc),
                    "balance": getattr(acc, "balance", 0),
                    "equity": getattr(acc, "equity", 0),
                    "currency": getattr(acc, "currency", ""),
                    "trading": ok,
                    "reason": why,
                    "version": VERSION,
                })
            if u.path == "/api/symbols":
                out = {}
                for key in WATCH:
                    name = resolve(key)
                    out[key] = sym_info(name) if name else None
                return self._json(200, out)
            if u.path == "/api/rates":
                name = q.get("symbol")
                tf = TF.get(q.get("tf", "d1"), mt5.TIMEFRAME_D1)
                count = max(30, min(1000, int(q.get("count", 220))))
                rates = mt5.copy_rates_from_pos(name, tf, 0, count)
                if rates is None or len(rates) == 0:
                    return self._json(404, {"error": "لا توجد بيانات لهذا الرمز"})
                bars = [{"t": int(r["time"]), "o": float(r["open"]), "h": float(r["high"]),
                         "l": float(r["low"]), "c": float(r["close"])} for r in rates]
                return self._json(200, {"symbol": name, "bars": bars})
            if u.path == "/api/quotes":
                out = {}
                for key in WATCH:
                    name = resolve(key)
                    if not name:
                        continue
                    r = mt5.copy_rates_from_pos(name, mt5.TIMEFRAME_D1, 0, 2)
                    if r is not None and len(r) == 2:
                        out[key] = {"last": float(r[1]["close"]), "prev": float(r[0]["close"])}
                return self._json(200, out)
            if u.path == "/api/positions":
                pos = [{
                    "ticket": p.ticket, "symbol": p.symbol,
                    "side": "buy" if p.type == mt5.POSITION_TYPE_BUY else "sell",
                    "volume": p.volume, "price": p.price_open, "sl": p.sl, "tp": p.tp, "profit": p.profit,
                } for p in (mt5.positions_get() or [])]
                ords = [{
                    "ticket": o.ticket, "symbol": o.symbol,
                    "side": "buy" if o.type in (mt5.ORDER_TYPE_BUY_LIMIT, mt5.ORDER_TYPE_BUY_STOP) else "sell",
                    "volume": o.volume_current, "price": o.price_open, "sl": o.sl, "tp": o.tp,
                } for o in (mt5.orders_get() or [])]
                acc = mt5.account_info()
                return self._json(200, {"positions": pos, "orders": ords,
                                        "currency": getattr(acc, "currency", "")})
        return self._json(404, {"error": "not found"})

    def do_POST(self):
        # الترويسة المخصّصة تمنع أي موقع آخر من إرسال أوامر عبر متصفحك
        if not self._host_ok() or self.headers.get("X-Mizan") != "1":
            return self._json(403, {"ok": False, "error": "forbidden"})
        try:
            n = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(n) or b"{}")
        except (ValueError, json.JSONDecodeError):
            return self._json(400, {"ok": False, "error": "طلب غير صالح"})
        with LOCK:
            if not mt5_ready():
                return self._json(503, {"ok": False, "error": "MetaTrader 5 غير متصل"})
            if self.path == "/api/order":
                code, data = place_order(body)
                print("[أمر]", body, "->", data)
                return self._json(code, data)
            if self.path == "/api/cancel":
                code, data = cancel_order(body)
                print("[إلغاء]", body, "->", data)
                return self._json(code, data)
        return self._json(404, {"ok": False, "error": "not found"})


def main():
    global ALLOW_REAL, MT5_PATH
    ap = argparse.ArgumentParser(description="Mizan bridge for MetaTrader 5")
    ap.add_argument("--mt5-path", help="مسار terminal64.exe إذا كان عندك أكثر من منصة")
    ap.add_argument("--allow-real", action="store_true", help="السماح بالتداول على حساب حقيقي")
    ap.add_argument("--no-browser", action="store_true")
    args = ap.parse_args()
    ALLOW_REAL = ALLOW_REAL or args.allow_real
    MT5_PATH = args.mt5_path or find_terminal()
    print(f"ميزان {VERSION} | المنصة: {MT5_PATH or 'تلقائي'} | بايثون {sys.version.split()[0]}")
    if sys.version_info >= (3, 15):
        print("تنبيه: مكتبة MetaTrader5 لا تدعم بايثون 3.15 بعد. شغّل الجسر بـ: py -3.14 mizan_bridge.py")

    if not mt5_init():
        print("تعذّر الاتصال بـ MetaTrader 5:", mt5.last_error())
        print("افتح MetaTrader 5 وسجّل الدخول بحساب Tickmill ثم أعد التشغيل.")
        sys.exit(1)
    acc = mt5.account_info()
    if acc:
        kind = "تجريبي" if is_demo(acc) else "حقيقي"
        print(f"متصل: {acc.company} | حساب {kind} #{acc.login} | الرصيد {acc.balance} {acc.currency}")
        if not is_demo(acc) and not ALLOW_REAL:
            print("تنبيه: هذا حساب حقيقي. الأسعار ستظهر لكن الأوامر مقفلة. استخدم --allow-real لفتحها.")
    url = f"http://{HOST}:{PORT}/"
    print("الواجهة تعمل على:", url, " (اضغط Ctrl+C للإيقاف)")
    if not args.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        mt5.shutdown()


if __name__ == "__main__":
    main()
